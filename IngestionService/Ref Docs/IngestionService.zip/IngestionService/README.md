# High-Throughput Event Ingestion Service

## Prerequisites
- .NET 10 SDK

## Build

```bash
dotnet build
```

## Run the API

```bash
dotnet run --project src/IngestionService.Api
```

By default this listens on `https://localhost:5001` / `http://localhost:5000`
(check the console output for the actual bound ports).

## Run tests

```bash
dotnet test
```

## Run the benchmark

```bash
dotnet run -c Release --project benchmarks/IngestionService.Benchmarks
```

## API

### `POST /readings`
Body: JSON array of up to 50,000 readings.

```json
[
  { "deviceId": "sensor-1", "timestamp": "2026-07-08T10:15:00Z", "value": 23.4 },
  { "deviceId": "sensor-2", "timestamp": "2026-07-08T10:15:01Z", "value": 19.9 }
]
```

Response:
```json
{ "accepted": 2 }
```

### `GET /readings/{deviceId}/aggregate`
Response (device has data in the last 5 minutes):
```json
{ "deviceId": "sensor-1", "count": 42, "min": 12.3, "max": 98.1, "average": 45.6 }
```
Response (unknown device or no readings in window): `404 Not Found`.

## Assumptions made (spec was deliberately open on these)

1. **Window boundary**: the window is `[now - 300s, now)` - a reading exactly
   300 seconds old is considered expired. See `DESIGN.md` for why a
   1-second-bucket approximation was chosen over an exact millisecond window.
2. **Malformed reading objects** (missing `deviceId`/`timestamp`/`value`) are
   silently skipped rather than failing the whole batch - one bad reading in
   a 50k batch shouldn't discard the other 49,999. `accepted` reflects only
   the readings actually applied.
3. **Readings older than the window at arrival time** (e.g. a very late
   straggler) are accepted by the endpoint (still counted toward HTTP 200)
   but do not affect any aggregate, since they could never appear in a query
   result anyway. This is called out explicitly in `DESIGN.md`.
4. **Timestamps** are parsed as UTC; if a timestamp arrives with a non-UTC
   offset it is normalized to UTC rather than rejected.
5. **Unknown device vs. device with zero current readings** are treated the
   same (`404`) - the spec doesn't require distinguishing "never seen" from
   "seen but window is empty," and a real dashboard consumer would treat
   both identically ("nothing to show right now").

## What I'd do next with more time

- Intern/cache `deviceId` strings to remove the one remaining per-reading
  allocation on the hot path (see comment in `ReadingStreamParser`).
- Add a `HttpClient`-based load test (e.g. via `bombardier`/`k6`) alongside
  the BenchmarkDotNet microbenchmarks, to validate throughput through the
  actual Kestrel pipeline rather than just the parsing/aggregation core.
- Idle-device cleanup: `AggregatorStore` never removes entries, so a
  long-running process that sees millions of distinct device IDs over its
  lifetime (vs. the spec's ~10,000) would grow unbounded. Not needed at the
  stated scale, flagged for completeness.

See `DESIGN.md` for the full design rationale.
